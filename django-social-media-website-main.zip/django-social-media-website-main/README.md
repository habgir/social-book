Link to the template files: https://github.com/tomitokko/django-social-media-template
